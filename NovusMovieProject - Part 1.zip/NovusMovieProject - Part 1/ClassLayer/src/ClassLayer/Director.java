package ClassLayer;


public class Director extends Person{
    
    public Director(String directorID, String directorName){
        super (directorID, directorName);
    }
    
}
