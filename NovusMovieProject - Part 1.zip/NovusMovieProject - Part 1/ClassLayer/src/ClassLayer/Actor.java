package ClassLayer;


public class Actor extends Person{
    
    public Actor(String actorID, String actorName){
        super (actorID, actorName);
    }
    
}
